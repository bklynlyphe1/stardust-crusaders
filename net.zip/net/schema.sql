drop table if exists posts;
	create table posts (
		id integer primary key,
		_name text not null,
		content text not null);
